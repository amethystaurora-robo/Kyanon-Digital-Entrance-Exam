# Kyanon-Digital-Entrance-Exam
# This project contains a Django starter app
# The database includes fields for Tasks, including Task ID, task Name, Task description, status, created date, modified date, and due date
# The database also includes a field for User ID, which is connected to Tasks with a foreign key
# APIS in this project include the ability to update files, get users by ID, assign tasks to particular users, get all task lists, get tasks by ID, and delete tasks
# The code can be deployed on PyCharm
