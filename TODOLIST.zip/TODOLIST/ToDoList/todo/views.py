from django.shortcuts import render
from django.http import HttpResponse
from todo import models
import requests

def addToDo(inputValue):
    inputValue = input("What would you like to add?")
    Tasks.add(inputValue)
    return


def getAllToDo():
    print(Tasks.object.all())
    return


def getToDoByID(ID):
    ID = input()
    print(Tasks.object.ID())
    return


def getAllUser():
    print(User.object.all())
    return


def updateToDo(requests, userUpdate):
    currentStatus = Tasks.status
    if currentStatus != COMPLETE:
        response = requests.post(userUpdate)
    return


def removeToDo(requests, userChoice):
    userChoice = input()
    models.userChoice.requests.delete
    return


def assignToDo(userTaskSelect, userUserSelect):
    userTaskSelect = input("Which task would you like to modify?")
    userUserSelect = input("Which user would you like to assign?")
    task = Tasks.objects.get(userTaskSelect)
    userID = User.objects.get(userUserSelect)
    task.Model = userID
    task.save()
    return
    
    
