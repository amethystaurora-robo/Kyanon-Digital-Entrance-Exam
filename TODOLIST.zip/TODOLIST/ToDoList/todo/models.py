from django.db import models

# Create your models here.

class User(models.Model):
    userID = models.IntegerField()

class Tasks(models.Model):
    task_ID = models.ForeignKey(User, on_delete=models.CASCADE)
    taskName = models.CharField(max_length=200)
    taskDescription = models.CharField(max_length=200)
    created_date = models.DateTimeField(auto_now_add=True)
    modified_date = models.DateTimeField(auto_now=True)
    completionDate = models.DateTimeField()
    status = models.TextChoices('NEW', 'COMPLETE')
